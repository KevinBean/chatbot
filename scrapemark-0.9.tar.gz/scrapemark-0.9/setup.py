from setuptools import setup
setup(
	name='scrapemark',
	version='0.9',
	py_modules=['scrapemark']
	)
